/* Shared helpers: live connection with auto-reconnect, sound unlock and chime, CSRF. */
(function () {
  "use strict";

  window.QLive = function (path, onMessage, onStatus) {
    var ws, tries = 0, pingTimer;
    function open() {
      var proto = location.protocol === "https:" ? "wss" : "ws";
      ws = new WebSocket(proto + "://" + location.host + path);
      ws.onopen = function () {
        tries = 0;
        if (onStatus) onStatus(true);
        pingTimer = setInterval(function () { try { ws.send('{"ping":1}'); } catch (e) {} }, 25000);
      };
      ws.onmessage = function (e) {
        var data; try { data = JSON.parse(e.data); } catch (err) { return; }
        if (!data.pong) onMessage(data);
      };
      ws.onclose = function () {
        clearInterval(pingTimer);
        if (onStatus) onStatus(false);
        tries += 1;
        setTimeout(open, Math.min(15000, 1000 * tries));
      };
    }
    open();
  };

  var ctx = null;
  window.QSound = {
    unlocked: false,
    unlock: function () {
      try {
        var Ctx = window.AudioContext || window.webkitAudioContext;
        if (!Ctx) return false;
        ctx = ctx || new Ctx();
        if (ctx.state === "suspended") ctx.resume();
        // a silent blip keeps iOS happy
        var o = ctx.createOscillator(), g = ctx.createGain();
        g.gain.value = 0.0001; o.connect(g); g.connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.05);
        this.unlocked = true;
        return true;
      } catch (e) { return false; }
    },
    chime: function (notes) {
      if (!ctx) return;
      notes = notes || [659, 880, 1047];
      notes.forEach(function (f, i) {
        var o = ctx.createOscillator(), g = ctx.createGain();
        o.frequency.value = f; o.connect(g); g.connect(ctx.destination);
        var t0 = ctx.currentTime + i * 0.25;
        g.gain.setValueAtTime(0.0001, t0);
        g.gain.exponentialRampToValueAtTime(0.3, t0 + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.6);
        o.start(t0); o.stop(t0 + 0.65);
      });
    }
  };

  window.QCsrf = function () {
    var m = document.cookie.match(/(?:^|;\s*)csrftoken=([^;]+)/);
    return m ? decodeURIComponent(m[1]) : "";
  };

  window.QGet = function (url) {
    return fetch(url, { credentials: "same-origin", headers: { "Accept": "application/json" } })
      .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); });
  };
  window.QPost = function (url) {
    return fetch(url, { method: "POST", credentials: "same-origin",
      headers: { "X-CSRFToken": window.QCsrf(), "Accept": "application/json" } })
      .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); });
  };
})();
