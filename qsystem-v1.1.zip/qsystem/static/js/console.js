(function () {
  "use strict";
  var cfg = window.Q_CONSOLE;
  var T = JSON.parse(document.getElementById("q-texts").textContent);
  var $ = function (id) { return document.getElementById(id); };
  var liveFor = null, busy = false, paused = false;

  function render(s) {
    paused = s.paused;
    var pb = $("pause");
    pb.textContent = s.paused ? T.on_break : T.available;
    pb.classList.toggle("paused", s.paused);
    $("no-station").hidden = s.has_station;
    $("desk").hidden = !s.has_station;
    if (s.message) $("msg").textContent = s.message;
    if (!s.has_station) return;

    $("station").textContent = s.station;
    var c = s.current;
    $("cur").hidden = !c;
    $("nobody").hidden = !!c;
    $("btn-recall").disabled = !c || !c.can_recall;
    if (c) {
      $("cur-num").textContent = c.ticket;
      $("cur-at").textContent = T.called_at + " " + c.called_at;
      $("cur-recalls").textContent = c.recall_count ? (T.recalled + " " + c.recall_count + " " + T.times) :
        (c.can_recall ? "" : T.recall_limit);
      $("suggest").hidden = !c.suggest_no_show;
      $("suggest").textContent = c.suggest_text;
    }
    $("st-seen").textContent = s.stats.seen;
    $("st-avg").textContent = s.stats.avg;
    $("st-ns").textContent = s.stats.no_shows;
    $("st-wait").textContent = s.waiting_count;
    $("q-count").textContent = s.waiting_count;

    var list = $("q-list");
    list.replaceChildren();
    s.waiting.forEach(function (w) {
      var row = document.createElement("div");
      row.className = "q-row";
      var n = document.createElement("strong"); n.dir = "ltr"; n.textContent = w.ticket;
      var a = document.createElement("span"); a.className = "muted"; a.textContent = T.took_number + " " + w.issued;
      var b = document.createElement("span"); b.textContent = w.wait_min + " " + T.minutes;
      row.append(n, a, b);
      list.append(row);
    });
    $("q-empty").hidden = s.waiting.length > 0;

    if (s.service_point && liveFor !== s.service_point) {
      liveFor = s.service_point;
      window.QLive("/ws/console/" + s.service_point + "/", function () { refresh(); },
        function (up) { if (up) refresh(); });
    }
  }

  function refresh() { return window.QGet(cfg.stateUrl).then(render).catch(function () {}); }

  function act(name) {
    if (busy) return;
    busy = true;
    $("msg").textContent = "";
    window.QPost(cfg.actionBase + name + "/").then(render)
      .catch(function () { $("msg").textContent = T.offline; })
      .finally(function () { busy = false; });
  }

  document.querySelectorAll("[data-act]").forEach(function (b) {
    b.addEventListener("click", function () { act(b.getAttribute("data-act")); });
  });
  $("pause").addEventListener("click", function () { act(paused ? "resume" : "pause"); });

  refresh();
  setInterval(refresh, 30000); // keeps minute counters fresh
})();
