(function () {
  "use strict";
  var cfg = window.Q_TICKET;
  var T = JSON.parse(document.getElementById("q-texts").textContent);
  var $ = function (id) { return document.getElementById(id); };
  var screens = ["s-waiting", "s-called", "s-ended"];
  var startAhead = null, lastStatus = null, lastRecalls = 0, wakeLock = null;

  function show(id) { screens.forEach(function (s) { $(s).hidden = s !== id; }); }

  function ring() {
    if (window.QSound.unlocked && cfg.chime) window.QSound.chime([880, 1175, 1568]);
    if (navigator.vibrate) navigator.vibrate([400, 150, 400, 150, 400]);
    var turn = $("s-called");
    turn.classList.remove("ringing"); void turn.offsetWidth; turn.classList.add("ringing");
  }

  function render(s) {
    if (s.status === "waiting") {
      show("s-waiting");
      if (startAhead === null || s.ahead > startAhead) startAhead = Math.max(s.ahead, 1);
      $("ahead").textContent = s.ahead;
      $("est").textContent = "~" + s.est_minutes + " " + T.minutes;
      $("progress").style.width = Math.round(((startAhead - s.ahead) / startAhead) * 100) + "%";
      $("warn").hidden = !s.warn;
    } else if (s.status === "called") {
      show("s-called");
      $("dest").textContent = cfg.lang === "ar" ? s.dest_ar : s.dest_en;
      $("turn-title").textContent = s.recall_count > 0 ? T.called_again : T.your_turn;
      if (lastStatus !== "called" || s.recall_count > lastRecalls) ring();
      lastRecalls = s.recall_count;
    } else {
      show("s-ended");
      var map = { done: [T.done_title, T.done_msg], no_show: [T.no_show_title, T.no_show_msg],
                  cancelled: [T.cancelled_title, ""] };
      var m = map[s.status] || ["", ""];
      $("end-title").textContent = m[0];
      $("end-msg").textContent = m[1];
      $("take-new").href = s.take_url;
    }
    lastStatus = s.status;
  }

  function refresh() { return window.QGet(cfg.stateUrl).then(render).catch(function () {}); }

  $("sound-btn").addEventListener("click", function () {
    window.QSound.unlock();
    if (navigator.vibrate) navigator.vibrate(80);
    if ("wakeLock" in navigator) {
      navigator.wakeLock.request("screen").then(function (w) { wakeLock = w; }).catch(function () {});
    }
    $("sound-btn").hidden = true;
    $("sound-on").hidden = false;
  });
  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "visible") {
      refresh();
      if (wakeLock !== null && "wakeLock" in navigator) {
        navigator.wakeLock.request("screen").then(function (w) { wakeLock = w; }).catch(function () {});
      }
    }
  });
  $("cancel").addEventListener("click", function () {
    if (!confirm(T.cancel_confirm)) return;
    window.QPost(cfg.cancelUrl).then(refresh).catch(refresh);
  });
  $("ack").addEventListener("click", function () { $("s-called").classList.remove("ringing"); });

  window.QLive("/ws/ticket/" + cfg.id + "/", function (msg) { refresh(); },
    function (up) { $("offline").hidden = up; if (up) refresh(); });
  refresh();
  setInterval(refresh, 20000); // safety net if the live connection drops quietly
})();
