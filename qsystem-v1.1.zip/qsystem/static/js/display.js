(function () {
  "use strict";
  var cfg = window.Q_DISPLAY;
  var $ = function (id) { return document.getElementById(id); };
  var queues = [], soundOn = false, flashTimer = null;
  var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  var months = ["January","February","March","April","May","June","July","August","September","October","November","December"];

  function el(tag, cls, text, dir) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    if (dir) e.dir = dir;
    return e;
  }

  function setHero(c, flash) {
    $("hero-num").textContent = c ? c.ticket : "—";
    $("hero-en").textContent = c ? c.dest_en : "";
    $("hero-ar").textContent = c ? c.dest_ar : "";
    if (flash) {
      var h = $("hero");
      h.classList.add("flash");
      clearTimeout(flashTimer);
      flashTimer = setTimeout(function () { h.classList.remove("flash"); }, 1500);
    }
  }

  function render(s) {
    queues = s.queues;
    setHero(s.current, false);
    var box = $("recent");
    box.replaceChildren();
    s.recent.slice(0, 6).forEach(function (r) {
      var row = el("div", "recent-row");
      row.append(el("strong", "", r.ticket, "ltr"), el("span", "", r.dest_en), el("span", "", r.dest_ar, "rtl"));
      box.append(row);
    });
    var tiles = $("waiting");
    tiles.replaceChildren();
    s.waiting.forEach(function (w) {
      var t = el("div", "tile");
      var names = el("div", "tile-names");
      names.append(el("span", "", w.en), el("span", "", w.ar, "rtl"));
      var line = el("div", "row-between");
      line.append(el("span", "tile-count", String(w.count)), el("span", "tile-names", cfg.waitingEn + " | " + cfg.waitingAr));
      t.append(names, line);
      tiles.append(t);
    });
  }

  function refresh() { return window.QGet(cfg.stateUrl).then(render).catch(function () {}); }

  function tick() {
    var d = new Date(), p = function (x) { return String(x).padStart(2, "0"); };
    $("time").textContent = p(d.getHours()) + ":" + p(d.getMinutes());
    $("date").textContent = days[d.getDay()] + " " + d.getDate() + " " + months[d.getMonth()];
  }

  $("sound").addEventListener("click", function () {
    soundOn = !soundOn;
    if (soundOn) { window.QSound.unlock(); window.QSound.chime(); }
    this.classList.toggle("on", soundOn);
    this.textContent = soundOn ? cfg.soundOnLabel : cfg.soundOffLabel;
  });

  window.QLive("/ws/display/" + cfg.slug + "/", function (msg) {
    if (msg.event !== "call") return;
    if (queues.length && queues.indexOf(msg.service_point) === -1) return;
    setHero({ ticket: msg.ticket, dest_en: msg.dest_en, dest_ar: msg.dest_ar }, true);
    if (soundOn && cfg.chime) window.QSound.chime();
    setTimeout(function () {
      window.QGet(cfg.stateUrl).then(function (s) {
        var hero = { ticket: msg.ticket, dest_en: msg.dest_en, dest_ar: msg.dest_ar };
        render(s);
        setHero(hero, false); // keep a recalled number on the hero even though it was first called earlier
      }).catch(function () {});
    }, 400);
  }, function (up) { if (up) refresh(); });

  tick(); setInterval(tick, 1000);
  refresh(); setInterval(refresh, 30000);
})();
