from django.apps import AppConfig


class OrgConfig(AppConfig):
    name = "org"
    verbose_name = "Clinics, counters and staff"
