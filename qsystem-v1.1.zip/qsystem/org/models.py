import uuid

from django.conf import settings
from django.db import models


class Department(models.Model):
    name_en = models.CharField("Name (English)", max_length=120)
    name_ar = models.CharField("Name (Arabic)", max_length=120)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["name_en"]

    def __str__(self):
        return self.name_en

    def name(self, lang):
        return self.name_ar if lang == "ar" else self.name_en


class ServicePoint(models.Model):
    """One queue: a clinic, or the pharmacy (whose counters share one queue)."""

    CLINIC = "clinic"
    PHARMACY = "pharmacy"
    KIND_CHOICES = [(CLINIC, "Clinic"), (PHARMACY, "Pharmacy")]

    kind = models.CharField(max_length=10, choices=KIND_CHOICES, default=CLINIC)
    code = models.CharField(max_length=10, unique=True,
                            help_text="Ticket prefix, e.g. C12 for clinic 12 or P for pharmacy.")
    short_en = models.CharField("Short name (English)", max_length=60, help_text="e.g. Clinic 12 or Pharmacy")
    short_ar = models.CharField("Short name (Arabic)", max_length=60, help_text="e.g. عيادة 12 أو الصيدلية")
    name_en = models.CharField("Specialty / full name (English)", max_length=120, help_text="e.g. Cardiology")
    name_ar = models.CharField("Specialty / full name (Arabic)", max_length=120, help_text="e.g. أمراض القلب")
    department = models.ForeignKey(Department, null=True, blank=True, on_delete=models.PROTECT,
                                   related_name="service_points")
    is_open = models.BooleanField("Taking numbers", default=True)
    qr_token = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    default_service_minutes = models.PositiveSmallIntegerField(
        default=6, help_text="Used for the waiting-time estimate until real data builds up today.")
    sort_order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["sort_order", "code"]
        verbose_name = "Clinic or pharmacy"
        verbose_name_plural = "Clinics and pharmacy"

    def __str__(self):
        return f"{self.short_en} ({self.name_en})"

    def short(self, lang):
        return self.short_ar if lang == "ar" else self.short_en

    def full_name(self, lang):
        return self.name_ar if lang == "ar" else self.name_en


class Station(models.Model):
    """A room inside a clinic or a counter inside the pharmacy."""

    service_point = models.ForeignKey(ServicePoint, on_delete=models.CASCADE, related_name="stations")
    label_en = models.CharField("Label (English)", max_length=60, help_text="e.g. Room 3 or Counter 2")
    label_ar = models.CharField("Label (Arabic)", max_length=60, help_text="e.g. غرفة 3 أو شباك 2")
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["service_point", "label_en"]
        unique_together = [("service_point", "label_en")]
        verbose_name = "Room or counter"
        verbose_name_plural = "Rooms and counters"

    def __str__(self):
        return f"{self.service_point.short_en}, {self.label_en}"

    def destination(self, lang):
        sp = self.service_point
        if lang == "ar":
            return f"{sp.short_ar}، {self.label_ar}"
        return f"{sp.short_en}, {self.label_en}"


class StaffProfile(models.Model):
    DOCTOR = "doctor"
    PHARMACIST = "pharmacist"
    OTHER = "other"
    ROLE_CHOICES = [(DOCTOR, "Doctor"), (PHARMACIST, "Pharmacist"), (OTHER, "Other staff")]

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="staff")
    name_en = models.CharField("Name (English)", max_length=120)
    name_ar = models.CharField("Name (Arabic)", max_length=120)
    role = models.CharField(max_length=12, choices=ROLE_CHOICES, default=DOCTOR)
    station = models.ForeignKey(Station, null=True, blank=True, on_delete=models.SET_NULL,
                                related_name="staff", help_text="Where this person is working now.")
    is_paused = models.BooleanField("On break", default=False)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["name_en"]
        verbose_name = "Doctor or pharmacist"
        verbose_name_plural = "Doctors and pharmacists"

    def __str__(self):
        return self.name_en

    def name(self, lang):
        return self.name_ar if lang == "ar" else self.name_en


class Display(models.Model):
    """A waiting-area screen. Leave 'queues' empty to show every clinic and the pharmacy."""

    name = models.CharField(max_length=80)
    slug = models.SlugField(unique=True, help_text="Used in the screen's address: /display/<slug>/")
    service_points = models.ManyToManyField(ServicePoint, blank=True, related_name="displays",
                                            verbose_name="queues shown")

    class Meta:
        verbose_name = "Waiting-area screen"

    def __str__(self):
        return self.name

    def queue_ids(self):
        ids = list(self.service_points.values_list("id", flat=True))
        return ids or list(ServicePoint.objects.values_list("id", flat=True))
