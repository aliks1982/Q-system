from django.contrib import admin
from django.urls import reverse
from django.utils.html import format_html

from .models import Department, Display, ServicePoint, StaffProfile, Station


@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ("name_en", "name_ar", "is_active")
    search_fields = ("name_en", "name_ar")


class StationInline(admin.TabularInline):
    model = Station
    extra = 1


@admin.register(ServicePoint)
class ServicePointAdmin(admin.ModelAdmin):
    list_display = ("code", "short_en", "name_en", "name_ar", "department", "kind", "is_open", "qr_link")
    list_editable = ("is_open",)
    list_filter = ("kind", "department", "is_open")
    search_fields = ("code", "short_en", "short_ar", "name_en", "name_ar")
    inlines = [StationInline]

    @admin.display(description="Patient QR")
    def qr_link(self, obj):
        return format_html('<a href="{}" target="_blank">Print poster</a>', reverse("qr_poster", args=[obj.pk]))


@admin.register(StaffProfile)
class StaffProfileAdmin(admin.ModelAdmin):
    list_display = ("name_en", "name_ar", "role", "station", "is_paused", "is_active")
    list_filter = ("role", "is_active")
    search_fields = ("name_en", "name_ar", "user__username")
    autocomplete_fields = ("user",)
    list_select_related = ("station__service_point",)


@admin.register(Station)
class StationAdmin(admin.ModelAdmin):
    list_display = ("__str__", "label_ar", "is_active")
    search_fields = ("label_en", "service_point__short_en", "service_point__code")


@admin.register(Display)
class DisplayAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "screen_link")
    prepopulated_fields = {"slug": ("name",)}
    filter_horizontal = ("service_points",)

    @admin.display(description="Open screen")
    def screen_link(self, obj):
        return format_html('<a href="{}" target="_blank">Open</a>', reverse("display", args=[obj.slug]))
