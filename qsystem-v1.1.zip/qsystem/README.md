# Q System — hospital queue management

Patients scan a clinic's QR code, take a number on their phone (no app), and get a sound + vibration
alert when called. Doctors and pharmacists call the next patient from any browser. Waiting-area screens
show and announce each call in Arabic and English. Hospital name, logo, colours and queue rules are set
by the administrator.

Stack: Django 5 + Channels (WebSockets), PostgreSQL, Redis, nginx — all in Docker, on-premises.
No patient names are stored; a phone number is optional (PDPL-friendly).

## Run it (Docker)

```bash
cp .env.example .env          # set SECRET_KEY, DB_PASSWORD, ALLOWED_HOSTS, PUBLIC_BASE_URL
docker compose up -d --build
docker compose exec web python manage.py createsuperuser
# optional sample clinics/pharmacy/staff:
docker compose exec web python manage.py seed_demo --password 'ChooseAStrongOne1!'
```

Open `http://<server>:8080/admin/`.

**HTTPS is required in production.** Phones only allow sound, vibration and "keep screen on" on secure pages,
and clinic QR codes should point at the HTTPS address. Put the hospital certificate on nginx (or the existing
reverse proxy) and set `DEBUG=0`.

## Run it on an internet server (automatic HTTPS)

Needs: Ubuntu server with a public IP, ports 80 and 443 open, and a domain name (e.g. `queue.example.com`)
whose DNS A record points to the server.

```bash
cp .env.example .env     # fill in DOMAIN, SECRET_KEY, DB_PASSWORD, ALLOWED_HOSTS, CSRF_TRUSTED_ORIGINS, PUBLIC_BASE_URL
docker compose -f docker-compose.cloud.yml up -d --build
docker compose -f docker-compose.cloud.yml exec web python manage.py createsuperuser
```
Update later with `git pull && docker compose -f docker-compose.cloud.yml up -d --build`.
Daily backups: `deploy/backup.sh` (see the comment inside for the cron line).

## Addresses

| Who | Address |
|---|---|
| Patient (from QR) | `/q/<clinic token>/` — printed by Admin › Clinics and pharmacy › *Print poster* |
| Doctor / pharmacist | `/console/` (sign in) |
| Waiting-area screen | `/display/<slug>/` — create in Admin › Waiting-area screens |
| Administration | `/admin/` |

## Setting up the hospital (Admin)

1. **Hospital, theme and rules** — names (EN/AR), logo, main colour, call colour, default language,
   no-show suggestion time, call-again limit, early warning, hours numbers can be taken.
   Text colour on each theme colour is picked automatically for readability.
2. **Departments**.
3. **Clinics and pharmacy** — one entry per queue. Code = ticket prefix (`C12` → `C12-034`). Add rooms
   (clinics) or counters (pharmacy) in the same form. All pharmacy counters share one queue.
4. **Doctors and pharmacists** — create a user (Authentication › Users), then a profile linking it to a room/counter.
5. **Waiting-area screens** — choose which queues each screen shows (empty = all). Open the screen address on the TV
   browser in full-screen and tap once to enable announcements.

## How the queue behaves

- One active number per phone per queue (scanning again returns to the same number).
- **Call next** finishes the patient at the desk and calls the lowest waiting number.
- **Call again** rings the phone and screen again, up to the configured limit.
- **Did not show** — the console suggests it after the configured minutes; staff decide.
- **Pause** stops calls for that staff member; the queue keeps its order.
- Waiting-time estimate = patients ahead × today's average visit time (or the clinic default until 3 visits
  are finished) ÷ staff on duty.

## Development

```bash
pip install -r requirements.txt
python manage.py migrate && python manage.py seed_demo
python manage.py runserver          # daphne serves HTTP + WebSockets
python manage.py test               # 20 tests: queue rules, pages, live push
```
Without `DATABASE_URL`/`REDIS_URL` it uses SQLite and an in-memory channel layer (single process only).

## Project layout

- `core/` hospital settings, theme colours, bilingual interface text (`texts.py`), language switch
- `org/` departments, clinics/pharmacy, rooms/counters, staff, screens
- `queues/` tickets, queue rules (`services.py` — the only place ticket status changes), live push
  (`realtime.py`, `consumers.py`), pages and JSON endpoints (`views.py`)
- `templates/`, `static/` phone pages, staff console, waiting-area screen, QR poster

## Milestone status

Done (milestone 1): QR tickets, patient phone alerts, staff console, pharmacy shared queue, waiting-area screen
with chime, admin setup incl. hospital name/logo/theme, QR posters, Docker deployment, tests.

Next (milestone 2): analytics dashboard (per staff / department / census), AI insights, recorded Arabic/English
voice announcements, custom settings pages matching the prototype (replacing Django admin for day-to-day use),
optional SMS backup, self-hosted fonts for offline networks.
