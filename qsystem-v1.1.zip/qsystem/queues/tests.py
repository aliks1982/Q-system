from datetime import time, timedelta

from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from core.models import SiteSettings
from core.theme import ink_for
from org.models import Display, ServicePoint, StaffProfile, Station

from . import services
from .models import Ticket


def make_staff(username, station, role="doctor"):
    user = get_user_model().objects.create_user(username, password="pass12345")
    return StaffProfile.objects.create(user=user, name_en=username, name_ar=username, role=role, station=station)


class QueueRulesTests(TestCase):
    def setUp(self):
        s = SiteSettings.load()
        s.issue_from, s.issue_until = time(0, 0), time(23, 59, 59)
        s.save()
        self.clinic = ServicePoint.objects.create(code="C12", short_en="Clinic 12", short_ar="عيادة 12",
                                                  name_en="Cardiology", name_ar="أمراض القلب")
        self.room = Station.objects.create(service_point=self.clinic, label_en="Room 3", label_ar="غرفة 3")
        self.doctor = make_staff("doc", self.room)
        self.pharmacy = ServicePoint.objects.create(code="P", kind="pharmacy", short_en="Pharmacy",
                                                    short_ar="الصيدلية", name_en="Pharmacy", name_ar="الصيدلية")
        self.c1 = Station.objects.create(service_point=self.pharmacy, label_en="Counter 1", label_ar="شباك 1")
        self.c2 = Station.objects.create(service_point=self.pharmacy, label_en="Counter 2", label_ar="شباك 2")
        self.ph1 = make_staff("ph1", self.c1, "pharmacist")
        self.ph2 = make_staff("ph2", self.c2, "pharmacist")

    def test_numbers_count_up_and_format(self):
        a, _ = services.issue_ticket(self.clinic, "phone-a")
        b, _ = services.issue_ticket(self.clinic, "phone-b")
        self.assertEqual((a.number, b.number), (1, 2))
        self.assertEqual(b.display_number, "C12-002")

    def test_one_active_number_per_phone(self):
        a, created1 = services.issue_ticket(self.clinic, "phone-a")
        again, created2 = services.issue_ticket(self.clinic, "phone-a")
        self.assertTrue(created1)
        self.assertFalse(created2)
        self.assertEqual(a.pk, again.pk)
        # a different queue is allowed
        p, created3 = services.issue_ticket(self.pharmacy, "phone-a")
        self.assertTrue(created3)

    def test_closed_queue_refuses(self):
        self.clinic.is_open = False
        self.clinic.save()
        with self.assertRaises(services.QueueError) as ctx:
            services.issue_ticket(self.clinic, "phone-a")
        self.assertEqual(ctx.exception.code, "closed")

    def test_outside_hours_refuses(self):
        s = SiteSettings.load()
        now = timezone.localtime()
        s.issue_from = (now + timedelta(hours=1)).time()
        s.issue_until = (now + timedelta(hours=2)).time()
        if s.issue_from > s.issue_until:  # near midnight, skip rather than flake
            return
        s.save()
        with self.assertRaises(services.QueueError) as ctx:
            services.issue_ticket(self.clinic, "phone-a")
        self.assertEqual(ctx.exception.code, "outside_hours")

    def test_call_next_in_order_and_finishes_previous(self):
        a, _ = services.issue_ticket(self.clinic, "a")
        b, _ = services.issue_ticket(self.clinic, "b")
        first = services.call_next(self.doctor)
        self.assertEqual(first.pk, a.pk)
        second = services.call_next(self.doctor)
        self.assertEqual(second.pk, b.pk)
        a.refresh_from_db()
        self.assertEqual(a.status, Ticket.DONE)
        self.assertIsNotNone(a.finished_at)
        self.assertIsNone(services.call_next(self.doctor))

    def test_pharmacy_counters_share_one_queue(self):
        t1, _ = services.issue_ticket(self.pharmacy, "a")
        t2, _ = services.issue_ticket(self.pharmacy, "b")
        got1 = services.call_next(self.ph2)
        got2 = services.call_next(self.ph1)
        self.assertEqual((got1.pk, got2.pk), (t1.pk, t2.pk))
        self.assertEqual(got1.station, self.c2)
        self.assertEqual(got2.station, self.c1)

    def test_paused_staff_cannot_call(self):
        services.issue_ticket(self.clinic, "a")
        services.set_paused(self.doctor, True)
        with self.assertRaises(services.QueueError) as ctx:
            services.call_next(self.doctor)
        self.assertEqual(ctx.exception.code, "paused")

    def test_recall_limit(self):
        services.issue_ticket(self.clinic, "a")
        services.call_next(self.doctor)
        limit = SiteSettings.load().max_recalls
        for _ in range(limit):
            services.recall(self.doctor)
        with self.assertRaises(services.QueueError) as ctx:
            services.recall(self.doctor)
        self.assertEqual(ctx.exception.code, "recall_limit")

    def test_no_show_and_finish(self):
        a, _ = services.issue_ticket(self.clinic, "a")
        b, _ = services.issue_ticket(self.clinic, "b")
        services.call_next(self.doctor)
        services.mark_no_show(self.doctor)
        a.refresh_from_db()
        self.assertEqual(a.status, Ticket.NO_SHOW)
        services.call_next(self.doctor)
        services.finish(self.doctor)
        b.refresh_from_db()
        self.assertEqual(b.status, Ticket.DONE)
        stats = services.staff_today_stats(self.doctor)
        self.assertEqual((stats["seen"], stats["no_shows"]), (1, 1))

    def test_position_and_estimate(self):
        tickets = [services.issue_ticket(self.clinic, f"p{i}")[0] for i in range(4)]
        pos = services.position(tickets[3])
        self.assertEqual(pos.ahead, 3)
        self.assertEqual(pos.est_minutes, 3 * self.clinic.default_service_minutes)

    def test_cancel_only_while_waiting(self):
        a, _ = services.issue_ticket(self.clinic, "a")
        services.cancel_ticket(a)
        a.refresh_from_db()
        self.assertEqual(a.status, Ticket.CANCELLED)
        # the phone can take a new number afterwards
        again, created = services.issue_ticket(self.clinic, "a")
        self.assertTrue(created)


class PageTests(TestCase):
    def setUp(self):
        s = SiteSettings.load()
        s.issue_from, s.issue_until = time(0, 0), time(23, 59, 59)
        s.save()
        self.clinic = ServicePoint.objects.create(code="C5", short_en="Clinic 5", short_ar="عيادة 5",
                                                  name_en="Internal medicine", name_ar="الباطنة")
        self.room = Station.objects.create(service_point=self.clinic, label_en="Room 1", label_ar="غرفة 1")
        self.doctor = make_staff("doc", self.room)
        Display.objects.create(name="Main", slug="main")

    def test_patient_flow_over_http(self):
        url = reverse("take", args=[self.clinic.qr_token])
        self.assertContains(self.client.get(url + "?lang=en"), "Get my number")
        resp = self.client.post(url)
        self.assertEqual(resp.status_code, 302)
        ticket = Ticket.objects.get()
        self.assertTrue(resp["Location"].endswith(f"/t/{ticket.pk}/"))
        # scanning again goes straight back to the same number
        self.assertEqual(self.client.get(url)["Location"], resp["Location"])
        state = self.client.get(reverse("ticket_state", args=[ticket.pk])).json()
        self.assertEqual((state["status"], state["number"], state["ahead"]), ("waiting", "C5-001", 0))

    def test_arabic_page_is_rtl(self):
        resp = self.client.get(reverse("take", args=[self.clinic.qr_token]) + "?lang=ar")
        self.assertContains(resp, 'dir="rtl"')
        self.assertContains(resp, "احصل على رقمي")

    def test_console_actions(self):
        services.issue_ticket(self.clinic, "a")
        self.client.login(username="doc", password="pass12345")
        data = self.client.post(reverse("console_action", args=["next"])).json()
        self.assertEqual(data["current"]["ticket"], "C5-001")
        data = self.client.post(reverse("console_action", args=["next"])).json()
        self.assertIsNone(data["current"])
        self.assertEqual(data["stats"]["seen"], 1)

    def test_console_requires_login(self):
        self.assertEqual(self.client.get(reverse("console")).status_code, 302)

    def test_display_state(self):
        services.issue_ticket(self.clinic, "a")
        services.issue_ticket(self.clinic, "b")
        services.call_next(self.doctor)
        data = self.client.get(reverse("display_state", args=["main"])).json()
        self.assertEqual(data["current"]["ticket"], "C5-001")
        self.assertEqual(data["current"]["dest_ar"], "عيادة 5، غرفة 1")
        self.assertEqual(data["waiting"][0]["count"], 1)

    def test_qr_poster_for_admin(self):
        get_user_model().objects.create_superuser("root", password="pass12345")
        self.client.login(username="root", password="pass12345")
        resp = self.client.get(reverse("qr_poster", args=[self.clinic.pk]))
        self.assertContains(resp, "<svg")

    def test_theme_colours_reach_pages(self):
        s = SiteSettings.load()
        s.primary_color, s.accent_color = "#1C3A6B", "#E0B04A"
        s.hospital_name_en = "Test Hospital"
        s.save()
        resp = self.client.get(reverse("take", args=[self.clinic.qr_token]) + "?lang=en")
        self.assertContains(resp, "--primary: #1C3A6B")
        self.assertContains(resp, "Test Hospital")

    def test_ink_contrast(self):
        self.assertEqual(ink_for("#F2B632"), "#10292B")
        self.assertEqual(ink_for("#0B5C5E"), "#FFFFFF")


class RealtimeTests(TestCase):
    """Calling a patient must push to the display group once the transaction commits."""

    def test_call_pushes_to_displays(self):
        s = SiteSettings.load()
        s.issue_from, s.issue_until = time(0, 0), time(23, 59, 59)
        s.save()
        sp = ServicePoint.objects.create(code="C1", short_en="Clinic 1", short_ar="عيادة 1", name_en="X", name_ar="X")
        st = Station.objects.create(service_point=sp, label_en="Room 1", label_ar="غرفة 1")
        doc = make_staff("d", st)
        layer = get_channel_layer()
        channel = async_to_sync(layer.new_channel)()
        async_to_sync(layer.group_add)("displays", channel)
        services.issue_ticket(sp, "a")
        with self.captureOnCommitCallbacks(execute=True):
            services.call_next(doc)
        msg = async_to_sync(layer.receive)(channel)
        self.assertEqual(msg["payload"]["event"], "call")
        self.assertEqual(msg["payload"]["ticket"], "C1-001")
        self.assertEqual(msg["payload"]["dest_en"], "Clinic 1, Room 1")
