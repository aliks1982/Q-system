import io
import secrets

import qrcode
import qrcode.image.svg
from django.conf import settings
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Q
from django.http import Http404, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.utils.safestring import mark_safe
from django.views.decorators.http import require_GET, require_POST

from core.models import SiteSettings
from core.texts import texts
from org.models import Display, ServicePoint, StaffProfile

from . import services
from .models import Ticket


def _error_text(err, lang):
    t = texts(lang)
    msg = t.get(err.code, err.code)
    return msg.format(**err.params) if err.params else msg


def _hm(dt):
    return timezone.localtime(dt).strftime("%H:%M") if dt else ""


# ---------------- patient ----------------

def take(request, token):
    sp = get_object_or_404(ServicePoint, qr_token=token)
    device = request.COOKIES.get(settings.DEVICE_COOKIE)
    error = None

    if device:
        existing = services.active_ticket_for_device(sp, device)
        if existing:
            return redirect("ticket", existing.pk)

    if request.method == "POST":
        new_device = device or secrets.token_urlsafe(24)
        try:
            ticket, _ = services.issue_ticket(sp, new_device, lang=request.lang,
                                              phone=request.POST.get("phone", "").strip())
        except services.QueueError as err:
            error = _error_text(err, request.lang)
        else:
            resp = redirect("ticket", ticket.pk)
            if not device:
                resp.set_cookie(settings.DEVICE_COOKIE, new_device, max_age=settings.DEVICE_COOKIE_AGE,
                                httponly=True, samesite="Lax", secure=not settings.DEBUG)
            return resp

    today = services.today()
    waiting = Ticket.objects.filter(service_point=sp, date=today, status=Ticket.WAITING).count()
    last_called = (Ticket.objects.filter(service_point=sp, date=today, called_at__isnull=False)
                   .order_by("-called_at").first())
    if error is None and not sp.is_open:
        error = texts(request.lang)["closed"]
    return render(request, "patient/take.html", {
        "sp": sp, "waiting": waiting, "now_serving": last_called.display_number if last_called else "—",
        "error": error,
    })


def ticket_page(request, ticket_id):
    ticket = get_object_or_404(Ticket.objects.select_related("service_point"), pk=ticket_id)
    return render(request, "patient/ticket.html", {"ticket": ticket, "sp": ticket.service_point})


@require_GET
def ticket_state(request, ticket_id):
    ticket = get_object_or_404(Ticket.objects.select_related("service_point", "station__service_point"),
                               pk=ticket_id)
    pos = services.position(ticket)
    site = SiteSettings.load()
    st = ticket.station
    return JsonResponse({
        "status": ticket.status,
        "number": ticket.display_number,
        "ahead": pos.ahead,
        "est_minutes": pos.est_minutes,
        "now_serving": pos.now_serving,
        "warn": ticket.status == Ticket.WAITING and 0 < pos.ahead <= site.warn_when_ahead,
        "dest_en": st.destination("en") if st else "",
        "dest_ar": st.destination("ar") if st else "",
        "recall_count": ticket.recall_count,
        "take_url": reverse("take", args=[ticket.service_point.qr_token]),
    })


@require_POST
def ticket_cancel(request, ticket_id):
    ticket = get_object_or_404(Ticket, pk=ticket_id)
    if request.COOKIES.get(settings.DEVICE_COOKIE) != ticket.device_id:
        raise Http404
    services.cancel_ticket(ticket)
    return JsonResponse({"ok": True})


# ---------------- waiting-area screen ----------------

def display_page(request, slug):
    display = get_object_or_404(Display, slug=slug)
    return render(request, "display/screen.html", {"display": display, "t_en": texts("en"), "t_ar": texts("ar")})


def _call_json(t):
    st = t.station
    return {
        "ticket": t.display_number,
        "service_point": t.service_point_id,
        "dest_en": st.destination("en") if st else t.service_point.short_en,
        "dest_ar": st.destination("ar") if st else t.service_point.short_ar,
    }


@require_GET
def display_state(request, slug):
    display = get_object_or_404(Display, slug=slug)
    ids = display.queue_ids()
    today = services.today()
    called = (Ticket.objects.filter(service_point_id__in=ids, date=today, called_at__isnull=False)
              .select_related("service_point", "station__service_point").order_by("-called_at")[:7])
    called = [_call_json(t) for t in called]
    counts = (ServicePoint.objects.filter(id__in=ids)
              .annotate(n=Count("tickets", filter=Q(tickets__date=today, tickets__status=Ticket.WAITING)))
              .order_by("sort_order", "code"))
    return JsonResponse({
        "queues": ids,
        "current": called[0] if called else None,
        "recent": called[1:],
        "waiting": [{"en": sp.name_en, "ar": sp.name_ar, "count": sp.n} for sp in counts],
    })


# ---------------- staff console ----------------

def _staff_or_none(request):
    return StaffProfile.objects.select_related("station__service_point").filter(
        user=request.user, is_active=True).first()


@login_required
def console(request):
    staff = _staff_or_none(request)
    if staff is None:
        if request.user.is_staff:
            return redirect("admin:index")
        raise Http404("No staff profile for this account.")
    return render(request, "staff/console.html", {"staff": staff})


def _console_json(staff, lang, message=""):
    t = texts(lang)
    site = SiteSettings.load()
    data = {"message": message, "paused": staff.is_paused, "has_station": bool(staff.station_id)}
    if not staff.station_id:
        return data
    sp = staff.station.service_point
    cur = services.current_ticket(staff)
    now = timezone.now()
    waiting_qs = (Ticket.objects.filter(service_point=sp, date=services.today(), status=Ticket.WAITING)
                  .order_by("number"))
    stats = services.staff_today_stats(staff)
    avg = stats["avg_seconds"]
    data.update({
        "station": staff.station.destination(lang),
        "service_point": sp.id,
        "current": None,
        "waiting_count": waiting_qs.count(),
        "waiting": [{"ticket": w.display_number, "issued": _hm(w.issued_at),
                     "wait_min": int((now - w.issued_at).total_seconds() // 60)} for w in waiting_qs[:10]],
        "stats": {"seen": stats["seen"], "no_shows": stats["no_shows"],
                  "avg": f"{avg // 60}m {avg % 60:02d}s" if avg else "—"},
    })
    if cur:
        mins = int((now - cur.called_at).total_seconds() // 60)
        data["current"] = {
            "ticket": cur.display_number, "called_at": _hm(cur.called_at), "minutes": mins,
            "recall_count": cur.recall_count, "can_recall": cur.recall_count < site.max_recalls,
            "suggest_no_show": mins >= site.no_show_minutes,
            "suggest_text": t["suggest_no_show"].format(min=mins),
        }
    return data


@login_required
@require_GET
def console_state(request):
    staff = _staff_or_none(request)
    if staff is None:
        raise Http404
    return JsonResponse(_console_json(staff, request.lang))


ACTIONS = {
    "next": services.call_next,
    "recall": services.recall,
    "no_show": services.mark_no_show,
    "finish": services.finish,
    "pause": lambda s: services.set_paused(s, True),
    "resume": lambda s: services.set_paused(s, False),
}


@login_required
@require_POST
def console_action(request, action):
    staff = _staff_or_none(request)
    if staff is None or action not in ACTIONS:
        raise Http404
    message = ""
    try:
        ACTIONS[action](staff)
    except services.QueueError as err:
        message = _error_text(err, request.lang)
    staff.refresh_from_db()
    return JsonResponse(_console_json(staff, request.lang, message))


# ---------------- QR posters ----------------

def _qr_svg(url):
    img = qrcode.make(url, image_factory=qrcode.image.svg.SvgPathImage, box_size=12, border=2)
    buf = io.BytesIO()
    img.save(buf)
    svg = buf.getvalue().decode()
    return svg[svg.find("<svg"):]


@staff_member_required
def qr_poster(request, pk):
    sp = get_object_or_404(ServicePoint, pk=pk)
    base = getattr(settings, "PUBLIC_BASE_URL", "") or request.build_absolute_uri("/")[:-1]
    url = base.rstrip("/") + reverse("take", args=[sp.qr_token])
    return render(request, "staff/qr_poster.html", {"sp": sp, "url": url, "qr": mark_safe(_qr_svg(url))})
