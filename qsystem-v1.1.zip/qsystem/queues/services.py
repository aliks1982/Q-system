"""Queue rules in one place. Views and tests call these; nothing else changes ticket status."""
from dataclasses import dataclass

from django.db import IntegrityError, connection, transaction
from django.db.models import Avg, DurationField, ExpressionWrapper, F
from django.utils import timezone

from core.models import SiteSettings
from org.models import ServicePoint, StaffProfile

from . import realtime
from .models import DailyCounter, Ticket


class QueueError(Exception):
    def __init__(self, code, **params):
        super().__init__(code)
        self.code = code
        self.params = params


def today():
    return timezone.localdate()


def _locked(qs, skip_locked=False):
    if not connection.features.has_select_for_update:
        return qs
    if skip_locked and connection.features.has_select_for_update_skip_locked:
        return qs.select_for_update(skip_locked=True)
    return qs.select_for_update()


# ---------- patient side ----------

def active_ticket_for_device(service_point, device_id):
    return (Ticket.objects.filter(service_point=service_point, date=today(), device_id=device_id,
                                  status__in=Ticket.ACTIVE).first())


def issue_ticket(service_point: ServicePoint, device_id: str, lang="ar", phone=""):
    """Returns (ticket, created). One active number per phone per queue."""
    site = SiteSettings.load()
    if not service_point.is_open:
        raise QueueError("closed")
    now_t = timezone.localtime().time()
    if not (site.issue_from <= now_t <= site.issue_until):
        raise QueueError("outside_hours", start=site.issue_from.strftime("%H:%M"),
                         end=site.issue_until.strftime("%H:%M"))

    existing = active_ticket_for_device(service_point, device_id)
    if existing:
        return existing, False

    for _ in range(3):  # retry if two phones create the day's first counter at the same moment
        try:
            with transaction.atomic():
                counter, _c = _locked(DailyCounter.objects).get_or_create(service_point=service_point, date=today())
                counter.last_number += 1
                counter.save(update_fields=["last_number"])
                ticket = Ticket.objects.create(service_point=service_point, date=counter.date,
                                               number=counter.last_number, device_id=device_id,
                                               lang=lang, phone=phone[:20])
                realtime.queue_changed(service_point.id)
                return ticket, True
        except IntegrityError:
            continue
    raise QueueError("busy")


def cancel_ticket(ticket: Ticket):
    with transaction.atomic():
        t = _locked(Ticket.objects).get(pk=ticket.pk)
        if t.status != Ticket.WAITING:
            return t
        t.status = Ticket.CANCELLED
        t.finished_at = timezone.now()
        t.save(update_fields=["status", "finished_at"])
        realtime.ticket_changed(t)
        return t


@dataclass
class Position:
    ahead: int
    est_minutes: int
    now_serving: str | None


def position(ticket: Ticket) -> Position:
    sp = ticket.service_point
    ahead = 0
    if ticket.status == Ticket.WAITING:
        ahead = Ticket.objects.filter(service_point=sp, date=ticket.date, status=Ticket.WAITING,
                                      number__lt=ticket.number).count()
    staffed = max(1, StaffProfile.objects.filter(station__service_point=sp, is_active=True,
                                                 is_paused=False).count())
    est = round(ahead * avg_service_minutes(sp) / staffed)
    last_called = (Ticket.objects.filter(service_point=sp, date=ticket.date, called_at__isnull=False)
                   .order_by("-called_at").first())
    return Position(ahead=ahead, est_minutes=est,
                    now_serving=last_called.display_number if last_called else None)


def avg_service_minutes(sp: ServicePoint) -> float:
    """Today's real average once there are a few finished visits, otherwise the configured default."""
    qs = Ticket.objects.filter(service_point=sp, date=today(), status=Ticket.DONE,
                               called_at__isnull=False, finished_at__isnull=False)
    if qs.count() >= 3:
        avg = qs.aggregate(a=Avg(ExpressionWrapper(F("finished_at") - F("called_at"),
                                                   output_field=DurationField())))["a"]
        if avg:
            return max(1.0, avg.total_seconds() / 60)
    return float(sp.default_service_minutes)


# ---------- staff side ----------

def _require_station(staff: StaffProfile):
    if not staff.station_id:
        raise QueueError("no_station")
    return staff.station


def current_ticket(staff: StaffProfile):
    if not staff.station_id:
        return None
    return (Ticket.objects.filter(station=staff.station, status=Ticket.CALLED, date=today())
            .select_related("service_point").order_by("-called_at").first())


def _finish_current(station, staff, status=Ticket.DONE):
    for t in _locked(Ticket.objects.filter(station=station, status=Ticket.CALLED)):
        t.status = status
        t.finished_at = timezone.now()
        t.save(update_fields=["status", "finished_at"])
        realtime.ticket_changed(t)


def call_next(staff: StaffProfile):
    """Finishes whoever is at this desk, then calls the lowest waiting number. Pharmacy counters share one queue."""
    station = _require_station(staff)
    if staff.is_paused:
        raise QueueError("paused")
    with transaction.atomic():
        _finish_current(station, staff)
        t = (_locked(Ticket.objects.filter(service_point_id=station.service_point_id, date=today(),
                                           status=Ticket.WAITING), skip_locked=True)
             .order_by("number").first())
        if t is None:
            realtime.queue_changed(station.service_point_id)
            return None
        t.status = Ticket.CALLED
        t.called_at = timezone.now()
        t.station = station
        t.served_by = staff
        t.save(update_fields=["status", "called_at", "station", "served_by"])
        realtime.announce_call(t)
        return t


def recall(staff: StaffProfile):
    t = current_ticket(staff)
    if t is None:
        raise QueueError("nobody")
    if t.recall_count >= SiteSettings.load().max_recalls:
        raise QueueError("recall_limit")
    with transaction.atomic():
        t = _locked(Ticket.objects).get(pk=t.pk)
        t.recall_count += 1
        t.save(update_fields=["recall_count"])
        realtime.announce_call(t, recall=True)
    return t


def mark_no_show(staff: StaffProfile):
    station = _require_station(staff)
    t = current_ticket(staff)
    if t is None:
        raise QueueError("nobody")
    with transaction.atomic():
        _finish_current(station, staff, status=Ticket.NO_SHOW)
    return t


def finish(staff: StaffProfile):
    station = _require_station(staff)
    t = current_ticket(staff)
    if t is None:
        raise QueueError("nobody")
    with transaction.atomic():
        _finish_current(station, staff)
    return t


def set_paused(staff: StaffProfile, paused: bool):
    staff.is_paused = paused
    staff.save(update_fields=["is_paused"])
    if staff.station_id:
        realtime.queue_changed(staff.station.service_point_id)


def staff_today_stats(staff: StaffProfile):
    qs = Ticket.objects.filter(served_by=staff, date=today())
    done = qs.filter(status=Ticket.DONE, finished_at__isnull=False)
    avg = done.aggregate(a=Avg(ExpressionWrapper(F("finished_at") - F("called_at"),
                                                 output_field=DurationField())))["a"]
    return {
        "seen": done.count(),
        "no_shows": qs.filter(status=Ticket.NO_SHOW).count(),
        "avg_seconds": int(avg.total_seconds()) if avg else None,
    }
