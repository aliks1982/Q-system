from django.contrib import admin

from .models import Ticket


@admin.register(Ticket)
class TicketAdmin(admin.ModelAdmin):
    list_display = ("display_number", "date", "status", "station", "served_by", "issued_at", "called_at",
                    "finished_at", "recall_count")
    list_filter = ("date", "status", "service_point")
    date_hierarchy = "date"
    list_select_related = ("service_point", "station__service_point", "served_by")
    readonly_fields = [f.name for f in Ticket._meta.fields]

    def has_add_permission(self, request):
        return False
