from django.urls import path

from .consumers import PushConsumer

websocket_urlpatterns = [
    path("ws/<str:kind>/<str:key>/", PushConsumer.as_asgi()),
]
