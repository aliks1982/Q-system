import uuid

from django.db import models
from django.utils import timezone

from org.models import ServicePoint, StaffProfile, Station


class DailyCounter(models.Model):
    """Hands out ticket numbers per queue per day, safely under concurrent scans."""

    service_point = models.ForeignKey(ServicePoint, on_delete=models.CASCADE)
    date = models.DateField()
    last_number = models.PositiveIntegerField(default=0)

    class Meta:
        unique_together = [("service_point", "date")]


class Ticket(models.Model):
    WAITING = "waiting"
    CALLED = "called"      # called to a room/counter; being served until finished
    DONE = "done"
    NO_SHOW = "no_show"
    CANCELLED = "cancelled"
    STATUS_CHOICES = [(WAITING, "Waiting"), (CALLED, "Called"), (DONE, "Finished"),
                      (NO_SHOW, "Did not show"), (CANCELLED, "Cancelled")]
    ACTIVE = (WAITING, CALLED)

    # UUID keeps ticket pages unguessable; no patient name is stored.
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    service_point = models.ForeignKey(ServicePoint, on_delete=models.PROTECT, related_name="tickets")
    date = models.DateField(db_index=True)
    number = models.PositiveIntegerField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default=WAITING)
    device_id = models.CharField(max_length=64, db_index=True)
    phone = models.CharField(max_length=20, blank=True)
    lang = models.CharField(max_length=2, default="ar")

    issued_at = models.DateTimeField(default=timezone.now)
    called_at = models.DateTimeField(null=True, blank=True)
    finished_at = models.DateTimeField(null=True, blank=True)
    station = models.ForeignKey(Station, null=True, blank=True, on_delete=models.SET_NULL)
    served_by = models.ForeignKey(StaffProfile, null=True, blank=True, on_delete=models.SET_NULL,
                                  related_name="tickets")
    recall_count = models.PositiveSmallIntegerField(default=0)

    class Meta:
        unique_together = [("service_point", "date", "number")]
        indexes = [models.Index(fields=["service_point", "date", "status"])]
        ordering = ["-date", "service_point", "number"]

    def __str__(self):
        return self.display_number

    @property
    def display_number(self):
        return f"{self.service_point.code}-{self.number:03d}"

    @property
    def wait_seconds(self):
        if self.called_at:
            return (self.called_at - self.issued_at).total_seconds()
        return None

    @property
    def service_seconds(self):
        if self.called_at and self.finished_at and self.status == self.DONE:
            return (self.finished_at - self.called_at).total_seconds()
        return None
