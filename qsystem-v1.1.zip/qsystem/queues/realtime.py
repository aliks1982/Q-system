"""Pushes live updates to phones, consoles and screens over WebSockets.

Messages are small 'something changed' events; pages then fetch fresh state over HTTP.
That keeps one source of truth (the database) and makes reconnects trivial.
"""
import logging

from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.db import transaction

log = logging.getLogger(__name__)

DISPLAYS = "displays"


def queue_group(service_point_id):
    return f"sp_{service_point_id}"


def ticket_group(ticket_id):
    return f"ticket_{ticket_id}"


def _send(group, payload):
    layer = get_channel_layer()
    if layer is None:
        return
    try:
        async_to_sync(layer.group_send)(group, {"type": "push", "payload": payload})
    except Exception:  # never let a push failure break a queue action
        log.exception("push to %s failed", group)


def queue_changed(service_point_id):
    transaction.on_commit(lambda: _send(queue_group(service_point_id), {"event": "queue"}))


def ticket_changed(ticket):
    tid, sp_id = str(ticket.id), ticket.service_point_id

    def go():
        _send(ticket_group(tid), {"event": "ticket"})
        _send(queue_group(sp_id), {"event": "queue"})
    transaction.on_commit(go)


def announce_call(ticket, recall=False):
    """A patient is being called: ring their phone and show it on the waiting-area screens."""
    station = ticket.station
    payload = {
        "event": "call",
        "recall": recall,
        "ticket": ticket.display_number,
        "service_point": ticket.service_point_id,
        "dest_en": station.destination("en") if station else ticket.service_point.short_en,
        "dest_ar": station.destination("ar") if station else ticket.service_point.short_ar,
    }
    tid, sp_id = str(ticket.id), ticket.service_point_id

    def go():
        _send(ticket_group(tid), {"event": "ticket", "ring": True})
        _send(DISPLAYS, payload)
        _send(queue_group(sp_id), {"event": "queue"})
    transaction.on_commit(go)
