from django.urls import path

from . import views

urlpatterns = [
    path("q/<uuid:token>/", views.take, name="take"),
    path("t/<uuid:ticket_id>/", views.ticket_page, name="ticket"),
    path("t/<uuid:ticket_id>/state/", views.ticket_state, name="ticket_state"),
    path("t/<uuid:ticket_id>/cancel/", views.ticket_cancel, name="ticket_cancel"),
    path("display/<slug:slug>/", views.display_page, name="display"),
    path("display/<slug:slug>/state/", views.display_state, name="display_state"),
    path("console/", views.console, name="console"),
    path("console/state/", views.console_state, name="console_state"),
    path("console/<str:action>/", views.console_action, name="console_action"),
    path("manage/qr/<int:pk>/", views.qr_poster, name="qr_poster"),
]
