from channels.db import database_sync_to_async
from channels.generic.websocket import AsyncJsonWebsocketConsumer

from org.models import Display, StaffProfile

from . import realtime
from .models import Ticket


class PushConsumer(AsyncJsonWebsocketConsumer):
    """One socket type for all pages. The URL says what to listen to:
    /ws/ticket/<uuid>/   a patient's phone
    /ws/display/<slug>/  a waiting-area screen
    /ws/console/<sp_id>/ a signed-in doctor or pharmacist
    """

    async def connect(self):
        kind = self.scope["url_route"]["kwargs"]["kind"]
        key = self.scope["url_route"]["kwargs"]["key"]
        self.groups_joined = await self._groups_for(kind, key)
        if not self.groups_joined:
            await self.close(code=4403)
            return
        for g in self.groups_joined:
            await self.channel_layer.group_add(g, self.channel_name)
        await self.accept()

    async def disconnect(self, code):
        for g in getattr(self, "groups_joined", []) or []:
            await self.channel_layer.group_discard(g, self.channel_name)

    async def receive_json(self, content, **kwargs):
        if content.get("ping"):
            await self.send_json({"pong": True})

    async def push(self, event):
        await self.send_json(event["payload"])

    @database_sync_to_async
    def _groups_for(self, kind, key):
        if kind == "ticket":
            t = Ticket.objects.filter(pk=key).only("id", "service_point_id").first() if _is_uuid(key) else None
            return [realtime.ticket_group(t.id), realtime.queue_group(t.service_point_id)] if t else []
        if kind == "display":
            return [realtime.DISPLAYS] if Display.objects.filter(slug=key).exists() else []
        if kind == "console":
            user = self.scope.get("user")
            if not (user and user.is_authenticated and key.isdigit()):
                return []
            ok = StaffProfile.objects.filter(user=user, is_active=True).exists()
            return [realtime.queue_group(int(key))] if ok else []
        return []


def _is_uuid(value):
    import uuid
    try:
        uuid.UUID(str(value))
        return True
    except ValueError:
        return False
