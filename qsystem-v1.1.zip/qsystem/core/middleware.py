from .models import SiteSettings

COOKIE = "qlang"


class LanguageMiddleware:
    """Picks Arabic or English from ?lang=, then the cookie, then the hospital default."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        chosen = request.GET.get("lang")
        if chosen not in ("ar", "en"):
            chosen = None
        lang = chosen or request.COOKIES.get(COOKIE)
        if lang not in ("ar", "en"):
            lang = SiteSettings.load().default_language
        request.lang = lang
        request.text_dir = "rtl" if lang == "ar" else "ltr"
        response = self.get_response(request)
        if chosen:
            response.set_cookie(COOKIE, chosen, max_age=60 * 60 * 24 * 365, samesite="Lax")
        return response
