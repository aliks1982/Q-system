"""Creates sample clinics, pharmacy counters, staff logins and one waiting-area screen for trying the system."""
from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.db import transaction

from core.models import SiteSettings
from org.models import Department, Display, ServicePoint, StaffProfile, Station

CLINICS = [
    ("C5", "Clinic 5", "عيادة 5", "Internal medicine", "الباطنة", "Medicine", 2),
    ("C8", "Clinic 8", "عيادة 8", "Orthopedics", "العظام", "Surgery", 1),
    ("C12", "Clinic 12", "عيادة 12", "Cardiology", "أمراض القلب", "Medicine", 3),
    ("C21", "Clinic 21", "عيادة 21", "Pediatrics", "الأطفال", "Pediatrics", 2),
    ("C33", "Clinic 33", "عيادة 33", "Dermatology", "الجلدية", "Medicine", 4),
]
DEPTS = {"Medicine": "الطب الباطني", "Surgery": "الجراحة", "Pediatrics": "طب الأطفال", "Pharmacy": "الصيدلية"}
STAFF = [
    ("dr.faisal", "Dr. Faisal Al-Otaibi", "د. فيصل العتيبي", "doctor", "C12", "Room 3"),
    ("dr.noura", "Dr. Noura Al-Qahtani", "د. نورة القحطاني", "doctor", "C21", "Room 2"),
    ("reem", "Reem Al-Shehri", "ريم الشهري", "pharmacist", "P", "Counter 2"),
    ("omar", "Omar Al-Zahrani", "عمر الزهراني", "pharmacist", "P", "Counter 1"),
]


class Command(BaseCommand):
    help = "Load sample data. Staff password is given with --password (default: ChangeMe123!)."

    def add_arguments(self, parser):
        parser.add_argument("--password", default="ChangeMe123!")

    @transaction.atomic
    def handle(self, *args, password, **opts):
        SiteSettings.load()
        depts = {en: Department.objects.get_or_create(name_en=en, defaults={"name_ar": ar})[0]
                 for en, ar in DEPTS.items()}
        for i, (code, s_en, s_ar, n_en, n_ar, dept, room) in enumerate(CLINICS):
            sp, _ = ServicePoint.objects.get_or_create(code=code, defaults=dict(
                kind=ServicePoint.CLINIC, short_en=s_en, short_ar=s_ar, name_en=n_en, name_ar=n_ar,
                department=depts[dept], sort_order=i))
            Station.objects.get_or_create(service_point=sp, label_en=f"Room {room}",
                                          defaults={"label_ar": f"غرفة {room}"})
        ph, _ = ServicePoint.objects.get_or_create(code="P", defaults=dict(
            kind=ServicePoint.PHARMACY, short_en="Pharmacy", short_ar="الصيدلية",
            name_en="Outpatient pharmacy", name_ar="صيدلية العيادات الخارجية",
            department=depts["Pharmacy"], sort_order=99, default_service_minutes=3))
        for n in range(1, 5):
            Station.objects.get_or_create(service_point=ph, label_en=f"Counter {n}",
                                          defaults={"label_ar": f"شباك {n}"})

        User = get_user_model()
        if not User.objects.filter(username="admin").exists():
            User.objects.create_superuser("admin", password=password)
        for username, en, ar, role, code, label in STAFF:
            user, created = User.objects.get_or_create(username=username)
            if created:
                user.set_password(password)
                user.save()
            station = Station.objects.get(service_point__code=code, label_en=label)
            StaffProfile.objects.update_or_create(user=user, defaults=dict(
                name_en=en, name_ar=ar, role=role, station=station))
        Display.objects.get_or_create(slug="main", defaults={"name": "Main waiting area"})
        self.stdout.write(self.style.SUCCESS(
            "Sample data ready. Logins: admin, dr.faisal, dr.noura, reem, omar. Screen: /display/main/"))
