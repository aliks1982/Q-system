"""Colour helpers so any colour the admin picks stays readable."""

DARK_INK = "#10292B"
LIGHT_INK = "#FFFFFF"


def _channels(hex_color):
    h = (hex_color or "#000000").lstrip("#")
    return [int(h[i:i + 2], 16) for i in (0, 2, 4)]


def luminance(hex_color):
    def lin(v):
        v = v / 255
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4

    r, g, b = (lin(c) for c in _channels(hex_color))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def ink_for(hex_color):
    """Dark or white text, whichever has more contrast on this background."""
    lum = luminance(hex_color)
    return DARK_INK if (lum + 0.05) / 0.05 > 1.05 / (lum + 0.05) else LIGHT_INK


def shade(hex_color, factor):
    """factor < 1 darkens, > 1 lightens (towards white)."""
    chans = _channels(hex_color)
    if factor < 1:
        chans = [round(c * factor) for c in chans]
    else:
        chans = [round(c + (255 - c) * (factor - 1)) for c in chans]
    return "#" + "".join(f"{max(0, min(255, c)):02X}" for c in chans)


def theme_for(site):
    return {
        "primary": site.primary_color,
        "primary_ink": ink_for(site.primary_color),
        "primary_dark": shade(site.primary_color, 0.7),
        "primary_soft": shade(site.primary_color, 1.85),
        "accent": site.accent_color,
        "accent_ink": ink_for(site.accent_color),
        "accent_soft": shade(site.accent_color, 1.8),
    }
