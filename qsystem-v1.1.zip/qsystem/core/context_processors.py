from .models import SiteSettings
from .texts import texts
from .theme import theme_for


def site(request):
    s = SiteSettings.load()
    lang = getattr(request, "lang", s.default_language)
    return {
        "site": s,
        "theme": theme_for(s),
        "lang": lang,
        "text_dir": "rtl" if lang == "ar" else "ltr",
        "other_lang": "en" if lang == "ar" else "ar",
        "t": texts(lang),
        "hospital_name": s.hospital_name_ar if lang == "ar" else s.hospital_name_en,
    }
