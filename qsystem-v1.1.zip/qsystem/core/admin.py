from django.contrib import admin
from django.utils.html import format_html

from .models import SiteSettings
from .theme import ink_for


@admin.register(SiteSettings)
class SiteSettingsAdmin(admin.ModelAdmin):
    readonly_fields = ("preview",)
    fieldsets = (
        ("Hospital", {"fields": ("hospital_name_en", "hospital_name_ar", "logo", "default_language")}),
        ("Theme", {"fields": ("primary_color", "accent_color", "preview"),
                   "description": "Text on each colour switches between dark and white automatically."}),
        ("Queue rules", {"fields": ("warn_when_ahead", "no_show_minutes", "max_recalls", "issue_from", "issue_until")}),
        ("Announcements", {"fields": ("chime_enabled", "arabic_first")}),
    )

    def has_add_permission(self, request):
        return not SiteSettings.objects.exists()

    def has_delete_permission(self, request, obj=None):
        return False

    def changelist_view(self, request, extra_context=None):
        from django.shortcuts import redirect
        obj = SiteSettings.load()
        return redirect("admin:core_sitesettings_change", obj.pk)

    @admin.display(description="Preview")
    def preview(self, obj):
        return format_html(
            '<div style="display:flex;gap:12px">'
            '<div style="padding:14px 22px;border-radius:12px;background:{};color:{};font-weight:700">Your number C12-034</div>'
            '<div style="padding:14px 22px;border-radius:12px;background:{};color:{};font-weight:700">It is your turn</div></div>',
            obj.primary_color, ink_for(obj.primary_color), obj.accent_color, ink_for(obj.accent_color),
        )
