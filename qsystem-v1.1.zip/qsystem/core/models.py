from datetime import time

from django.core.validators import RegexValidator
from django.db import models

hex_color = RegexValidator(r"^#[0-9A-Fa-f]{6}$", "Use a colour like #0B5C5E.")


class SiteSettings(models.Model):
    """One row for the whole hospital: name, logo, colours and queue rules."""

    LANG_CHOICES = [("ar", "Arabic"), ("en", "English")]

    hospital_name_en = models.CharField("Hospital name (English)", max_length=200, default="Hospital name")
    hospital_name_ar = models.CharField("Hospital name (Arabic)", max_length=200, default="اسم المستشفى")
    logo = models.ImageField(upload_to="branding/", blank=True, help_text="PNG, JPG or SVG. Square works best.")
    primary_color = models.CharField("Main colour", max_length=7, default="#0B5C5E", validators=[hex_color])
    accent_color = models.CharField("Call colour", max_length=7, default="#F2B632", validators=[hex_color],
                                    help_text="Used for 'your turn' and the 'now calling' panel.")
    default_language = models.CharField(max_length=2, choices=LANG_CHOICES, default="ar",
                                        help_text="Language a patient sees first. They can switch at any time.")

    warn_when_ahead = models.PositiveSmallIntegerField(
        default=2, help_text="Tell the patient to come close when this many people are ahead.")
    no_show_minutes = models.PositiveSmallIntegerField(
        default=5, help_text="After this many minutes the console suggests marking the patient as did not show.")
    max_recalls = models.PositiveSmallIntegerField(default=3, help_text="How many times a patient can be called again.")
    issue_from = models.TimeField("Numbers can be taken from", default=time(7, 0))
    issue_until = models.TimeField("Numbers can be taken until", default=time(22, 0))
    chime_enabled = models.BooleanField("Chime before each call", default=True)
    arabic_first = models.BooleanField("Arabic first on screens", default=True)

    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Hospital, theme and rules"
        verbose_name_plural = "Hospital, theme and rules"

    def __str__(self):
        return self.hospital_name_en

    def save(self, *args, **kwargs):
        self.pk = 1
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        pass

    @classmethod
    def load(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj
