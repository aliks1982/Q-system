#!/bin/sh
# Daily database backup, keeps 30 days. Schedule with: crontab -e  ->  30 2 * * * /home/<user>/qsystem/deploy/backup.sh
set -e
cd "$(dirname "$0")/.."
mkdir -p backups
docker compose -f docker-compose.cloud.yml exec -T db pg_dump -U qsystem qsystem | gzip > "backups/qsystem-$(date +%F).sql.gz"
find backups -name '*.sql.gz' -mtime +30 -delete
